# Perfect Builder Contractor Ltd Website

Files:
- `index.html` — complete website
- `style.css` — responsive light-blue / black / white design
- `script.js` — mobile menu + active navigation

Contact details included:
- Phone / WhatsApp: +44 7391 931969
- Email: perfectbuilder95@yahoo.com
- Location: Sheffield, UK
- Website: perfectbuilder.uk

## GitHub Pages
Upload all three files to the `main` branch root. Then:
Settings → Pages → Deploy from a branch → `main` → `/ (root)` → Save.

The site uses remote Unsplash images, so internet access is required for the project photos.
